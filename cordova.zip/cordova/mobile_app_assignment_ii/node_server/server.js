import express from 'express'
const app = express()
const port = 3000
import mongodb from 'mongodb'
const MongoClient = mongodb.MongoClient;


const uri = 'mongodb+srv://piyusharma058:TLUU0V3g35WUDr0F@cordovaapi.2nx9rgp.mongodb.net/Rest-Api?retryWrites=true&w=majority'

const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
// Global for general use
let currCollection;

client.connect(err => {
   currCollection = client.db("products").collection("all_products");
  // perform actions on the collection object
  console.log ('Database up!');

  console.log(err);
 
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect();
    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}
run().catch(console.dir);


//get
app.get('/', (req, res) => {
res.send('')
})

app.listen(port, () => {
console.log(`Node server is running on port ${port}`)
})
