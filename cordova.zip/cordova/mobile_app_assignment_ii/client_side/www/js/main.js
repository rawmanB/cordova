$(document).on( 'pageinit', function(e, ui) {

const pageContainer = $.mobile.pageContainer;

//on swipe right show nav menu in mobile and on swipe left hide
pageContainer.on("swiperight", function(e) {

    if ($(".ui-page-active").jqmData("panel") !== "open") {
        if (e.type === "swiperight") {
            $("#left-panel").panel("open");
        }
    }

});
return;
});
//Validate form fields using validate method of jquery

    $("#contact-form").validate({
    errorPlacement: function(error, element) {
        if (element.attr("name") == "name") {
            error.insertAfter("#name-label");
        } else if (element.attr("name") == "age") {
            error.insertAfter("#age-label");
        } else if (element.attr("name") == "email") {
            error.insertAfter("#email-label");
        }
    },
    rules: {
        name: {
            required: true
        },
        age: {
            required: true,
            number: true,
            minlength: 1,
            maxlength: 3
        },
        email: {
            required: true,
            email: true
        }
    },
    messages: {
        name: {
            required: "Please enter your name."
        },
        age: {
            required: "Please enter your age .",
            number: "Please enter a valid age .",
            minlength: "Please enter at least 1 digits.",
            maxlength: "Please enter no more than 3 digits."
        },
        email: {
            required: "Please enter your email address.",
            email: "Please enter a valid email address."
        }
    },
    errorPlacement: function(error, element) {
error.appendTo(element.parent().prev());
},
submitHandler: function() {
   
    // Create a new object to store the current form data
    var data = {
        name: $("#name").val(),
        age: $("#age").val(),
        email: $("#email").val()
    };
    // Add the new form data object to the form data array
    formDataArray.push(data);
    // Store the updated form data array in local storage
    localStorage.setItem("form-data-array", JSON.stringify(formDataArray));
    // Show popup with submitted data
    $("#name-data").text(data.name);
    $("#age-data").text(data.age);
    $("#email-data").text(data.email);
    alert('Your imformation has been stored, thankyou')

    $("#form")[0].reset();
    //Alert for message
}
    });
//Reset form fields
$("#clear-form").on("click", function() {
    $("#form")[0].reset();
});

$('.flipper').click(function() {		        
    $(this).toggleClass('flip');
});

//form data from local storage
var formDataArray = JSON.parse(localStorage.getItem("form-data-array")) || [];
// Get existing form data array from local storage, or create a new one if it doesn't exist


function getFormData(){
    for (var i = 0; i < formDataArray.length; i++) {
        var table = $('#formdata-table tbody')
        var formData = formDataArray[i];
        var name = formData.name;
        var age = formData.age;
        var email = formData.email;

        var tr = document.createElement('tr');
        var nameCell = document.createElement("td");
        nameCell.append(name);
        $(tr).append(nameCell);

        var ageCell = document.createElement("td");
        ageCell.append(age);
        $(tr).append(ageCell);


        var emailCell = document.createElement("td");
        emailCell.append(email);
        $(tr).append(emailCell);

        $(table).append(tr)

    }
}
$(document).ajaxStop(function(){
    getFormData();
});


// Define the API endpoint
var apiEndpoint = "https://dummyjson.com/products";

// Define the function to get a random product
function getRandomProduct() {
    // Make an AJAX call to the API endpoint to retrieve all products
    $.ajax({
    url: apiEndpoint,
    method: "GET",
    dataType: "json",
    success: function(response) {
        // Generate a random index to select a single product from the response
        var randomIndex = Math.floor(Math.random() * response.products.length);

        // Get the random product
        var randomProduct = response.products[randomIndex];

        var title = document.createElement('h2');
        title.append(randomProduct.title);

        var img = $("<img>");
        img.attr('src', randomProduct.thumbnail);

        var desc = document.createElement('p');
        desc.append(randomProduct.description);
        // Update the product text with the random product information
        $("#product").empty();
        $("#product").append(img);
        $("#product").append(title);
        $("#product").append(desc);
    },
    error: function(error) {
        console.log(error);
    }
    });
}

// Call the function to get a random product on page load
getRandomProduct();

// Add a click event listener to the refresh button to get a new random product
$("#refresh-btn").click(function() {
    getRandomProduct();
});

$(document).on("click", "#change-theme-button-d", function() {
  var page = $("body").pagecontainer("getActivePage");
  page.removeClass("ui-page-theme-a").addClass("ui-page-theme-b");
});
$(document).on("click", "#change-theme-button-l", function() {
  var page = $("body").pagecontainer("getActivePage");
  page.removeClass("ui-page-theme-b").addClass("ui-page-theme-a");
});
